var mockProductList = [
    {   
        pno : 1,
        name : "Do it ! 자바프로그래밍 입문",
        description : "자바 프로그래밍을 입문하는데 있어서 최적의 책!",
        price : 15500,
        src : "resources/images/java.jpg"
    } , 
    {   
        pno : 2,
        name : "Do it ! 오라클로 배우는 데이터베이스 입문",
        description : "오라클을 입문하는데 있어서 최적의 책!",
        price : 20000,
        src : "resources/images/oracle.jpg"
    } , 
    {   
        pno : 3,
        name : "Do it! 리액트 네이티브 앱 프로그래밍",
        description : "리액트 네이티브를 입문하는데 있어서 최적의 책!",
        price : 44200,
        src : "resources/images/react.jpg"
    } , 
    {   
        pno : 4,
        name : "Do it ! HTML+CSS+자바스크립트 웹 표준의 정석",
        description : "HTML+CSS+자바스크립트 프로그래밍을 입문하는데 있어서 최적의 책!",
        price : 30000,
        src : "resources/images/html.jpg"
    } , 
    {   
        pno : 5,
        name : "JSP 웹 프로그래밍과 스프링 프레임워크",
        description : "JSP를 입문하는데 있어서 최적의 책!",
        price : 27000,
        src : "resources/images/jsp.jpg"
    } , 
    {   
        pno : 6,
        name : "리액트 200제",
        description : "리액트를 입문하는데 있어서 최적의 책!",
        price : 22500,
        src : "resources/images/react200.PNG"
    } , 
    {   
        pno : 7,
        name : "Do it! 자바스크립트 입문",
        description : "자바스크립트를 입문하는데 있어서 최적의 책!",
        price : 16200,
        src : "resources/images/js.png"
    } , 
    {   
        pno : 8,
        name : "Do it ! Node.js 프로그래밍 입문",
        description : "Node.js을 입문하는데 있어서 최적의 책!",
        price : 32400,
        src : "resources/images/node.png"
    } , 
] 

// ---------------- 검색기능과 관련된 코드 시작----------------


// ---------------- 검색기능과 관련된 코드 끝----------------


// ---------------- 모달기능과 관련된 코드 시작----------------


// ---------------- 모달기능과 관련된 코드 끝----------------


// ---------------- 장바구니추가 관련된 코드 시작--------------


// ---------------- 장바구니추가 관련된 코드 끝----------------


// ---------------- 장바구니상품 가격계산 관련된 코드 시작--------------


// ---------------- 장바구니상품 가격계산 관련된 코드 끝----------------